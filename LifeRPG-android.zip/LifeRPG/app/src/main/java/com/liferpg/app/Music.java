package com.liferpg.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.provider.Settings;
import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;

/** 再生中の曲の取得と操作（⏮ ⏯ ⏭）、YouTube Music を開く */
public class Music {
    static final String YTM = "com.google.android.apps.youtube.music";
    private static String lastKey = "";
    private static String lastArt = "";

    static boolean granted(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(c.getPackageName());
    }

    static void openSettings(Context c) {
        Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    private static MediaController current(Context c) {
        if (!granted(c)) return null;
        try {
            MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = m.getActiveSessions(new ComponentName(c, MediaListener.class));
            if (list == null || list.isEmpty()) return null;
            MediaController best = null;
            for (MediaController mc : list) {   // 再生中のもの → YouTube Music → 先頭 の順で選ぶ
                PlaybackState st = mc.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) return mc;
                if (YTM.equals(mc.getPackageName()) && best == null) best = mc;
            }
            return best != null ? best : list.get(0);
        } catch (Exception e) {
            return null;
        }
    }

    static String now(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("granted", granted(c));
            MediaController mc = current(c);
            if (mc == null) return o.toString();
            MediaMetadata md = mc.getMetadata();
            PlaybackState st = mc.getPlaybackState();
            o.put("pkg", mc.getPackageName());
            o.put("app", Bridge.labelOf(c, mc.getPackageName()));
            o.put("playing", st != null && st.getState() == PlaybackState.STATE_PLAYING);
            if (md != null) {
                String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                o.put("title", title == null ? "" : title);
                o.put("artist", artist == null ? "" : artist);
                String key = mc.getPackageName() + "|" + title;
                if (!key.equals(lastKey)) {   // 曲が変わったときだけジャケットを作り直す
                    lastKey = key;
                    lastArt = "";
                    Bitmap b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    if (b != null) {
                        Bitmap s = Bitmap.createScaledBitmap(b, 96, 96, true);
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        s.compress(Bitmap.CompressFormat.JPEG, 80, bo);
                        lastArt = "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                    }
                }
                o.put("art", lastArt);
            }
        } catch (Exception ignored) { }
        return o.toString();
    }

    static void cmd(Context c, String cmd) {
        MediaController mc = current(c);
        if (mc == null) return;
        MediaController.TransportControls t = mc.getTransportControls();
        PlaybackState st = mc.getPlaybackState();
        boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
        switch (cmd) {
            case "toggle": if (playing) t.pause(); else t.play(); break;
            case "next": t.skipToNext(); break;
            case "prev": t.skipToPrevious(); break;
        }
    }

    static boolean installed(Context c) {
        try { c.getPackageManager().getPackageInfo(YTM, 0); return true; } catch (Exception e) { return false; }
    }

    /** YouTube Music のURL（プレイリスト・検索）をアプリで開く。なければブラウザ */
    static void open(Context c, String url) {
        Intent i;
        if (url == null || url.isEmpty()) {
            i = c.getPackageManager().getLaunchIntentForPackage(YTM);
            if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/"));
        } else {
            i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (installed(c) && url.contains("youtube.com")) i.setPackage(YTM);
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { c.startActivity(i); } catch (Exception e) {
            Intent b = new Intent(Intent.ACTION_VIEW, Uri.parse(url == null || url.isEmpty() ? "https://music.youtube.com/" : url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { c.startActivity(b); } catch (Exception ignored) { }
        }
    }
}
