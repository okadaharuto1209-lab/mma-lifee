package com.liferpg.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.Settings;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/** JavaScript（ゲーム）から呼べるネイティブ機能 */
public class Bridge {
    static final String PREF = "lock";
    private final Context ctx;
    private final MainActivity act;

    Bridge(MainActivity a) {
        act = a;
        ctx = a.getApplicationContext();
    }

    static String labelOf(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    @JavascriptInterface
    public boolean isNative() { return true; }

    /** ホーム画面に出るアプリの一覧 [{pkg,label}] */
    @JavascriptInterface
    public String getApps() {
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        HashSet<String> seen = new HashSet<>();
        List<String[]> apps = new ArrayList<>();
        for (ResolveInfo r : list) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(ctx.getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new String[]{pkg, r.loadLabel(pm).toString()});
        }
        Collections.sort(apps, (a, b) -> a[1].compareToIgnoreCase(b[1]));
        java.util.Set<String> ess = Launcher.essentials(ctx);
        JSONArray arr = new JSONArray();
        try {
            for (String[] a : apps) {
                JSONObject o = new JSONObject();
                o.put("pkg", a[0]);
                o.put("label", a[1]);
                if (ess.contains(a[0])) o.put("essential", true);
                arr.put(o);
            }
        } catch (Exception ignored) { }
        return arr.toString();
    }

    /**
     * ロック設定を保存。判定は BlockerService が行う。
     * @param enabled    ロック機能オン/オフ
     * @param blocked    ロックするパッケージ名のJSON配列
     * @param clearedDate 必須クエストを全部クリアした日（yyyy-MM-dd）。今日と一致すれば解除
     * @param passUntil  緊急パスの有効期限（ミリ秒, 文字列）
     */
    @JavascriptInterface
    public void setLockConfig(boolean enabled, String blocked, String clearedDate, String passUntil) {
        long until = 0;
        try { until = (long) Double.parseDouble(passUntil); } catch (Exception ignored) { }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean("enabled", enabled)
                .putString("blocked", blocked == null ? "[]" : blocked)
                .putString("cleared", clearedDate == null ? "" : clearedDate)
                .putLong("passUntil", until)
                .apply();
    }

    /** ユーザー補助（アクセシビリティ）でアプリロックが有効になっているか */
    @JavascriptInterface
    public boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(ctx.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName me = new ComponentName(ctx, BlockerService.class);
        TextUtils.SimpleStringSplitter sp = new TextUtils.SimpleStringSplitter(':');
        sp.setString(enabled);
        while (sp.hasNext()) {
            ComponentName c = ComponentName.unflattenFromString(sp.next());
            if (me.equals(c)) return true;
        }
        return false;
    }

    @JavascriptInterface
    public void openAccessibilitySettings() {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /** Android 13以降の「制限付き設定」を解除するためのアプリ情報画面 */
    @JavascriptInterface
    public void openAppInfo() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + ctx.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /* ---------- Health Connect（睡眠・歩数・運動） ---------- */

    @JavascriptInterface
    public int healthStatus() { return act.health.status(); }

    @JavascriptInterface
    public void healthRequest() { act.health.requestPermissions(); }

    @JavascriptInterface
    public void healthFetch() { act.health.fetch(); }

    @JavascriptInterface
    public void healthInstall() { act.health.openInstall(); }

    /* ---------- スクリーンタイム ---------- */

    @JavascriptInterface
    public boolean usageGranted() { return ScreenTime.granted(ctx); }

    @JavascriptInterface
    public void openUsageSettings() {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /** daysAgo=0 今日 / 1 昨日 */
    @JavascriptInterface
    public String getScreenTime(int daysAgo) { return ScreenTime.collect(ctx, daysAgo); }

    /* ---------- ランチャー ---------- */

    @JavascriptInterface
    public boolean launcherEnabled() { return Launcher.enabled(ctx); }

    @JavascriptInterface
    public void setLauncher(boolean on) {
        Launcher.set(ctx, on);
        Launcher.openHomeSettings(ctx);
    }

    @JavascriptInterface
    public boolean isDefaultHome() { return Launcher.isDefaultHome(ctx); }

    @JavascriptInterface
    public void openHomeSettings() { Launcher.openHomeSettings(ctx); }

    @JavascriptInterface
    public void openAppDetails(String pkg) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /* ---------- ミュージック ---------- */

    @JavascriptInterface
    public boolean musicAccess() { return Music.granted(ctx); }

    @JavascriptInterface
    public void openMusicAccess() { Music.openSettings(ctx); }

    @JavascriptInterface
    public String musicNow() { return Music.now(ctx); }

    @JavascriptInterface
    public void musicCmd(String cmd) { Music.cmd(ctx, cmd); }

    @JavascriptInterface
    public void musicOpen(String url) { Music.open(ctx, url); }

    /**
     * アプリ一覧＋アイコンを裏で用意して window.onApps(json) で返す（画面を止めない）。
     * アイコンは端末内に保存して使い回すので、2回目からは速い。
     */
    @JavascriptInterface
    public void loadApps() {
        new Thread(() -> {
            String json = buildApps(true);
            act.js("window.onApps&&window.onApps(" + JSONObject.quote(json) + ")");
        }).start();
    }

    private String buildApps(boolean withIcons) {
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        HashSet<String> seen = new HashSet<>();
        List<String[]> apps = new ArrayList<>();
        for (ResolveInfo r : list) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(ctx.getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new String[]{pkg, r.loadLabel(pm).toString()});
        }
        Collections.sort(apps, (a, b) -> a[1].compareToIgnoreCase(b[1]));
        java.util.Set<String> ess = Launcher.essentials(ctx);
        java.io.File dir = new java.io.File(ctx.getCacheDir(), "icons");
        if (withIcons) dir.mkdirs();
        JSONArray arr = new JSONArray();
        for (String[] a : apps) {
            try {
                JSONObject o = new JSONObject();
                o.put("pkg", a[0]);
                o.put("label", a[1]);
                if (ess.contains(a[0])) o.put("essential", true);
                if (withIcons) {
                    long ver = 0;
                    try { ver = pm.getPackageInfo(a[0], 0).lastUpdateTime; } catch (Exception ignored) { }
                    java.io.File f = new java.io.File(dir, a[0] + "_" + ver + ".png");
                    if (!f.exists()) {
                        java.io.File[] old = dir.listFiles((d, n) -> n.startsWith(a[0] + "_"));
                        if (old != null) for (java.io.File x : old) x.delete();
                        android.graphics.Bitmap bm = iconBitmap(a[0]);
                        if (bm != null) {
                            try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
                                bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fo);
                            }
                        }
                    }
                    if (f.exists()) o.put("icon", "file://" + f.getAbsolutePath());
                }
                arr.put(o);
            } catch (Exception ignored) { }
        }
        return arr.toString();
    }

    /** 端末の形で切り抜かず、四角いアイコン画像を作る */
    private android.graphics.Bitmap iconBitmap(String pkg) {
        try {
            android.graphics.drawable.Drawable d = ctx.getPackageManager().getApplicationIcon(pkg);
            int size = 96;
            android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas cv = new android.graphics.Canvas(b);
            if (d instanceof android.graphics.drawable.AdaptiveIconDrawable) {
                android.graphics.drawable.AdaptiveIconDrawable ad = (android.graphics.drawable.AdaptiveIconDrawable) d;
                int pad = size / 4;
                android.graphics.drawable.Drawable bg = ad.getBackground(), fg = ad.getForeground();
                if (bg != null) { bg.setBounds(-pad, -pad, size + pad, size + pad); bg.draw(cv); }
                if (fg != null) { fg.setBounds(-pad, -pad, size + pad, size + pad); fg.draw(cv); }
            } else {
                d.setBounds(0, 0, size, size);
                d.draw(cv);
            }
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** スマホに入っているアプリのアイコン（PNGのdata URL）。入っていなければ空 */
    @JavascriptInterface
    public String appIcon(String pkg) {
        android.graphics.Bitmap b = iconBitmap(pkg);
        if (b == null) return "";
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        b.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bo);
        return "data:image/png;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP);
    }

    /** 指定したアプリを開く（再生中の音楽アプリなど） */
    @JavascriptInterface
    public void openApp(String pkg) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { Music.open(ctx, ""); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /* ---------- 通知制限 ---------- */

    /** 通知を消すアプリ（パッケージ名のJSON配列） */
    @JavascriptInterface
    public void setNotifBlock(String json) {
        ctx.getSharedPreferences(MediaListener.PREF, Context.MODE_PRIVATE).edit().putString("list", json == null ? "[]" : json).apply();
    }

    /** 今日ブロックした通知の数 {"パッケージ名": 件数} */
    @JavascriptInterface
    public String getNotifCounts() { return MediaListener.counts(ctx); }

    /* ---------- アプリの時間制限 ---------- */

    /** {"パッケージ名": 分} */
    @JavascriptInterface
    public void setLimits(String json) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("limits", json == null ? "{}" : json).apply();
    }

    /** 今日の使用時間（分） {"パッケージ名": 分} */
    @JavascriptInterface
    public String getUsageToday() { return Usage.todayMinutes(ctx); }

    /* ---------- リマインダー ---------- */

    @JavascriptInterface
    public void setReminders(String json) { Reminders.save(ctx, json); }

    @JavascriptInterface
    public void setDone(String date, String idsJson) { Reminders.setDone(ctx, date, idsJson); }

    @JavascriptInterface
    public boolean notifEnabled() {
        android.app.NotificationManager nm =
                (android.app.NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.areNotificationsEnabled();
    }

    @JavascriptInterface
    public void requestNotif() { act.requestNotificationPermission(); }

    /** クリア演出のバイブ。pattern は "0,60,40,120" のようなミリ秒の並び */
    @JavascriptInterface
    public void vibrate(String pattern) {
        try {
            String[] ps = pattern.split(",");
            long[] t = new long[ps.length];
            for (int k = 0; k < ps.length; k++) t[k] = Long.parseLong(ps[k].trim());
            android.os.Vibrator v = (android.os.Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(android.os.VibrationEffect.createWaveform(t, -1));
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void copyText(String text) {
        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("LifeRPG", text));
    }
}
