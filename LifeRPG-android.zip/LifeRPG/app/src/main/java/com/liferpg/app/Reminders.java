package com.liferpg.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** ゲームで設定したリマインダーを Android のアラームに登録する */
public class Reminders {
    static final String PREF = "reminders";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** リマインダー一覧（JSON配列）を保存して全部登録し直す */
    static void save(Context c, String json) {
        prefs(c).edit().putString("list", json == null ? "[]" : json).apply();
        scheduleAll(c);
    }

    /** 今日クリア済みのクエストID（クリア済みなら通知しない） */
    static void setDone(Context c, String date, String idsJson) {
        prefs(c).edit().putString("doneDate", date).putString("doneIds", idsJson == null ? "[]" : idsJson).apply();
    }

    static JSONArray list(Context c) {
        try {
            return new JSONArray(prefs(c).getString("list", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static void scheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences p = prefs(c);
        // 前回登録した分を取り消す
        try {
            JSONArray old = new JSONArray(p.getString("scheduled", "[]"));
            for (int k = 0; k < old.length(); k++) am.cancel(pending(c, old.getInt(k)));
        } catch (Exception ignored) { }
        JSONArray now = new JSONArray();
        JSONArray arr = list(c);
        for (int k = 0; k < arr.length(); k++) {
            JSONObject r = arr.optJSONObject(k);
            if (r == null || !r.optBoolean("on", true)) continue;
            int id = r.optInt("id");
            long t = nextTime(r.optInt("h"), r.optInt("m"));
            // 省電力中でも鳴る（数分ずれることがある）。正確なアラーム権限は不要
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pending(c, id));
            now.put(id);
        }
        p.edit().putString("scheduled", now.toString()).apply();
    }

    static PendingIntent pending(Context c, int id) {
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("rid", id);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static long nextTime(int h, int m) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, h);
        cal.set(Calendar.MINUTE, m);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 30_000) cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTimeInMillis();
    }
}
