package com.liferpg.app

import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Health Connect（Google Fit・Samsung Health・Fitbit などのデータが集まる場所）から
 * 睡眠・歩数・運動を読み取り、ゲーム（JavaScript）に渡す。
 */
class HealthBridge(private val act: ComponentActivity, private val web: WebView) {

    private val pSleep = HealthPermission.getReadPermission(SleepSessionRecord::class)
    private val pSteps = HealthPermission.getReadPermission(StepsRecord::class)
    private val pExercise = HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    private val perms = setOf(pSleep, pSteps, pExercise)

    // onCreate 中に登録する必要がある
    private val launcher: ActivityResultLauncher<Set<String>> =
        act.registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
            js("window.onHealthPerm&&window.onHealthPerm(${granted.isNotEmpty()})")
        }

    /** 3=使える 2=Health Connectの更新が必要 1=使えない */
    fun status(): Int = try {
        HealthConnectClient.getSdkStatus(act)
    } catch (e: Exception) {
        HealthConnectClient.SDK_UNAVAILABLE
    }

    fun requestPermissions() {
        act.runOnUiThread {
            try {
                launcher.launch(perms)
            } catch (e: Exception) {
                js("window.onHealthPerm&&window.onHealthPerm(false)")
            }
        }
    }

    fun openInstall() {
        act.runOnUiThread {
            val uri = Uri.parse("market://details?id=com.google.android.apps.healthdata&url=healthconnect%3A%2F%2Fonboarding")
            val i = Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.vending")
            try {
                act.startActivity(i)
            } catch (e: Exception) {
                act.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata")))
            }
        }
    }

    /** 昨夜の睡眠・今日の歩数・今日の運動を読み取って window.onHealthData(json) を呼ぶ */
    fun fetch() {
        act.lifecycleScope.launch {
            val out = JSONObject()
            try {
                if (status() != HealthConnectClient.SDK_AVAILABLE) {
                    out.put("error", "unavailable")
                } else {
                    val client = HealthConnectClient.getOrCreate(act)
                    val granted = client.permissionController.getGrantedPermissions()
                    out.put("granted", granted.isNotEmpty())
                    val zone = ZoneId.systemDefault()
                    val today = LocalDate.now(zone)
                    val startToday = today.atStartOfDay(zone).toInstant()
                    val now = Instant.now()

                    if (granted.contains(pSleep)) {
                        // 昨日の18時〜今 に終わった睡眠を合計（昼寝も含む）
                        val from = today.minusDays(1).atTime(18, 0).atZone(zone).toInstant()
                        val res = client.readRecords(
                            ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(from, now))
                        )
                        var mins = 0L
                        for (r in res.records) {
                            val s = if (r.startTime.isBefore(from)) from else r.startTime
                            mins += Duration.between(s, r.endTime).toMinutes()
                        }
                        out.put("sleepMin", mins)
                    }

                    if (granted.contains(pSteps)) {
                        val agg = client.aggregate(
                            AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), TimeRangeFilter.between(startToday, now))
                        )
                        out.put("steps", agg[StepsRecord.COUNT_TOTAL] ?: 0L)
                    }

                    if (granted.contains(pExercise)) {
                        val res = client.readRecords(
                            ReadRecordsRequest(ExerciseSessionRecord::class, TimeRangeFilter.between(startToday, now))
                        )
                        val arr = JSONArray()
                        for (r in res.records) {
                            val cat = when (r.exerciseType) {
                                ExerciseSessionRecord.EXERCISE_TYPE_RUNNING,
                                ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "run"
                                ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
                                ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING,
                                ExerciseSessionRecord.EXERCISE_TYPE_CALISTHENICS -> "str"
                                ExerciseSessionRecord.EXERCISE_TYPE_MARTIAL_ARTS,
                                ExerciseSessionRecord.EXERCISE_TYPE_BOXING -> "fight"
                                ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "walk"
                                else -> "other"
                            }
                            val o = JSONObject()
                            o.put("id", r.metadata.id)
                            o.put("cat", cat)
                            o.put("min", Duration.between(r.startTime, r.endTime).toMinutes())
                            o.put("title", r.title ?: "")
                            arr.put(o)
                        }
                        out.put("exercises", arr)
                    }
                }
            } catch (e: Exception) {
                out.put("error", e.message ?: "error")
            }
            js("window.onHealthData&&window.onHealthData(${JSONObject.quote(out.toString())})")
        }
    }

    private fun js(s: String) {
        web.post { web.evaluateJavascript(s, null) }
    }
}
