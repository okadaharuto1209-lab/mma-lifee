package com.liferpg.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Set;

/**
 * 「通知へのアクセス」用のサービス。
 * ・再生中の曲（YouTube Music など）の表示・操作
 * ・通知制限：選んだアプリの通知を、来た瞬間に消す
 * 見るのは「どのアプリの通知か」だけで、通知の中身（文章）は読まない。
 */
public class MediaListener extends NotificationListenerService {
    static final String PREF = "notif";

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) handle(s);
        } catch (Exception ignored) { }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        handle(sbn);
    }

    private void handle(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;
        Set<String> ess = Launcher.essentials(this);
        if (ess.contains(pkg)) return; // 電話・SMS・設定は絶対に止めない
        if (!blocked(this, pkg)) return;
        try {
            cancelNotification(sbn.getKey());
            count(this, pkg);
        } catch (Exception ignored) { }
    }

    static boolean blocked(Context c, String pkg) {
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]"));
            for (int k = 0; k < a.length(); k++) if (pkg.equals(a.optString(k))) return true;
        } catch (Exception ignored) { }
        return false;
    }

    /** 今日ブロックした数をアプリごとに数える */
    static void count(Context c, String pkg) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            String today = Usage.today();
            JSONObject m = today.equals(p.getString("date", "")) ? new JSONObject(p.getString("counts", "{}")) : new JSONObject();
            m.put(pkg, m.optInt(pkg, 0) + 1);
            p.edit().putString("date", today).putString("counts", m.toString()).apply();
        } catch (Exception ignored) { }
    }

    static String counts(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return Usage.today().equals(p.getString("date", "")) ? p.getString("counts", "{}") : "{}";
    }
}
